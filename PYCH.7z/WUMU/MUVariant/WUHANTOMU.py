fileP1 = "ORF1AB_WUHAN.fasta"
newFile = "ORF1AB_MU.fasta"
fO = open(newFile, 'w')
with open(fileP1) as fP:
    for line in fP:
        counter = 1
        for letter in line:
            #print(letter)
            if counter == 1055:
                print(letter)
                letter = "A"
            elif counter == 1538:
                print("1538 ", letter)
                letter = "I"
            elif counter == 3729:
                print("3729 ", letter)
                letter = "R"
            elif counter == 4715:
                print("4715 ", letter)
                letter = "L"
            elif counter == 5743:
                print("5743 ", letter)
                letter = "S"
            fO.write(letter)
            counter = counter + 1
fO.close()