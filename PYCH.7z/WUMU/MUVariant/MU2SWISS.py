file1 = "ORF1AB_MU.fasta"
newDoc = "ORF1AB_MU_SP.fasta"
fO = open(newDoc, 'w')
with open(file1) as f1:
    for l in f1:
        counter = 1
        for lettter in l:
            print(lettter)
            if counter > 1050 and counter < 5745:
                fO.write(lettter)
            counter = counter + 1

