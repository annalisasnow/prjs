filePath = "SPROTEIN_WUHAN.fasta"

fNew = "SPROTEIN_MU.fasta"
fNO = open(fNew, 'w')

with open(filePath) as fP:
    for line in fP:
        counter = 1
        for letter in line:
            if counter == 95:
                letter = "I"
            elif counter == 144:
                letter = "T"
            elif counter == 145:
                letter = "S"
            elif counter == 146:
                letter = letter + "N"
            elif counter == 346:
                letter = "K"
            elif counter == 484:
                letter = "K"
            elif counter == 501:
                letter = "Y"
            elif counter == 681:
                letter = "H"

            fNO.write(letter)
            counter = counter + 1