filePath = "ORF3A_WUHAN.fasta"

newFP = "ORF3A_MU.fasta"
fO = open(newFP, 'w')

with open(filePath) as fP:
    for line in fP:
        print(line)
        counter = 1
        for letter in line:
            print(letter)
            print(counter)
            if counter == 170:
                print(letter)
                letter = "T"
            elif counter > 764 and counter < 769:
                print(letter)
                letter = ""
            fO.write(letter)

            counter = counter + 1