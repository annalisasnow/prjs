fileP = "ORF8_WUHAN.fasta"

fileNew = "ORF8_MU.fasta"
fOPen = open(fileNew, "w")

with open(fileP) as fN:
    for line in fN:
        print(line)
        counter = 1
        for letter in line:
            print(letter)
            if counter == 11:
                letter = "K"
            elif counter == 38:
                letter = "S"
            elif counter == 67:
                letter = "F"
            fOPen.write(letter)
            counter = counter + 1

fOPen.close()