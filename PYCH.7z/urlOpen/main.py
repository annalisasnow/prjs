import urllib.request
from bs4 import BeautifulSoup as BS
with urllib.request.urlopen('https://www.ncbi.nlm.nih.gov/assembly/GCF_006493975.1/') as f:
    #      <input type="hidden" class="download-datasets-base-url" id="download-datasets-base-url-1" value="https://api.ncbi.nlm.nih.gov/datasets/v1alpha/protein/accession/WP_103014080.1/download" />

    html = f.read().decode('utf-8')
    fNew = "test2.html"
    fO = open(fNew, 'w')
    fO.write(html)
    fO.close()
    print(html)
