filePath = "sequence.txt"
newFile = "sqAltered.txt"
arrLines = []
with open(filePath, 'r') as fP:
    for line in fP:
        print(line)
        newLine = "".join(line.strip().split(" ")[1:])
        print(newLine)
        arrLines.append(newLine)
arrLines[-1] = arrLines[-1].strip()
fO = open(newFile, 'w')
for i in arrLines:
    fO.write(i.strip())
fO.close()
strSeq = ""
def replace_str_index(text,index=0,replacement=''):
    return '%s%s%s'%(text[:index],replacement,text[index:])
with open("sqAltered.txt", 'r') as sqar:
    for l in sqar:
        print(l)
        strSeq = l.strip()
print(strSeq[27526])
print(strSeq[27525])
print(strSeq[27527])
print(strSeq[27528])
strSeq2 = list(strSeq)
strSeq2 = replace_str_index(strSeq, index=27526, replacement="t")
strSeq2 = "".join(strSeq2)
file2 = "sqAltered2.txt"
fOpen = open(file2, 'w')
fOpen.write(strSeq2)
fOpen.close()
print("WROTE")

proteinWuhan = strSeq[27393:27759]
proteinMutation = strSeq2[27393:27759] #цифры - локация гена
file1Prot = "ProtWuHanMakarovSeq.txt"
file2Prot = "ProtMutMakarov.txt"
fOpen1 = open(file1Prot, 'w')
fOpen1.write(proteinWuhan)
fOpen1.close()
fOpen2 = open(file2Prot, 'w')
fOpen2.write(proteinMutation)
fOpen2.close()
import difflib

output_list = [li for li in difflib.ndiff(strSeq, strSeq2) if li[0] != ' ']
print("DIFF", output_list)
print("TEST!!!")