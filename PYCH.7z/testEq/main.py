a=float(input('a='))
b=float(input('b='))
c=float(input('c='))
if a==0 and b==0:
    if c==0:
        print('Identity')
    else:
        print('No solutions')
elif a==0:
    x=-c/b
    print(f"Linear equation: x= {x}")
else:
    D=b**2-4*a*c
    if D<0:
        from cmath import sqrt
        print('Complex numbers:')
        D2=sqrt(D)
    elif D==0:
        x=-b/(2*a)
        print(f"The only root: x= {x}")
        D2=0
    else:
        from math import sqrt
        print('Real numbers:')
    x1=(-b-D2)/(2*a)
    x2=(-b+D2)/(2*a)
    print(f"x1={x1}; x2={x2}")