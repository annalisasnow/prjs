import urllib.request as r

filePath = "compound2process.txt"
x = "000000000000"
with open(filePath) as fP:
    for line in fP:
        #print(line)
        if "ADORA2A" in line:
            print(line)
            zincID = line.split(" ")[0]
            print(zincID)
            #https://zinc.docking.org/substances/ZINC000003924085.smi
            urlPt1 = "https://zinc.docking.org/substances/ZINC"
            middleURL = x[:-len(zincID)] + zincID
            endLine = ".smi"
            fullLink = urlPt1 + middleURL + endLine
            fullFileName = "dirSMI/" + middleURL + endLine
            r.urlretrieve(fullLink, fullFileName)